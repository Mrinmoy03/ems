import { EmployeeProfile, EmployeeNotification } from "../types/employee"

export const initialMockEmployee: EmployeeProfile = {
  id: "EMP-1042",
  firstName: "Alex",
  lastName: "Morgan",
  email: "alex.morgan@worktrack.io",
  designation: "Senior Frontend Engineer",
  department: "Product Engineering",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  joinDate: "2023-03-15",
  phone: "+1 (555) 382-9012",
  location: "San Francisco, CA",
}

export const initialMockNotifications: EmployeeNotification[] = []
