import {
  AdminEmployee,
  Department,
  AdminTask,
  AdminAttendanceDay,
  AdminSuperAdminComment,
  DeadlineChangeRecord,
  AdminDailyReport,
} from "../types/admin"

export const initialDepartments: Department[] = [
  {
    id: "DEP-ENG",
    name: "Product Engineering",
    code: "ENG",
    description: "Core web, mobile, backend systems and API services engineering.",
    headEmployeeId: "",
    headEmployeeName: "",
    employeeCount: 0,
    activeTasksCount: 0,
    isArchived: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
  },
  {
    id: "DEP-DSN",
    name: "Design System",
    code: "DSN",
    description: "UI/UX component architecture, design tokens, brand design, and accessibility.",
    headEmployeeId: "",
    headEmployeeName: "",
    employeeCount: 0,
    activeTasksCount: 0,
    isArchived: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
  },
  {
    id: "DEP-OPS",
    name: "Operations & QA",
    code: "OPS",
    description: "DevOps cloud infrastructure, automated regression pipelines, and operational reliability.",
    headEmployeeId: "",
    headEmployeeName: "",
    employeeCount: 0,
    activeTasksCount: 0,
    isArchived: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
  },
  {
    id: "DEP-MKT",
    name: "Marketing & Growth",
    code: "MKT",
    description: "Inbound growth, product launches, client collateral, and technical documentation.",
    headEmployeeId: "",
    headEmployeeName: "",
    employeeCount: 0,
    activeTasksCount: 0,
    isArchived: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
  },
  {
    id: "DEP-HR",
    name: "Human Resources",
    code: "HR",
    description: "Talent acquisition, organizational development, policy compliance, and employee welfare.",
    headEmployeeId: "",
    headEmployeeName: "",
    employeeCount: 0,
    activeTasksCount: 0,
    isArchived: false,
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
  },
]

export const initialAdminEmployees: AdminEmployee[] = []

export const initialDeadlineHistory: DeadlineChangeRecord[] = []

export const initialAdminTasks: AdminTask[] = []

export const initialAdminAttendance: AdminAttendanceDay[] = []

export const initialSuperAdminComments: AdminSuperAdminComment[] = []

export const initialAdminLeaveRequests: any[] = []

export const initialAdminReports: AdminDailyReport[] = []
